ExampleMediaController
======================

This is an example project that goes with http://www.brightec.co.uk/blog/custom-android-media-controller
